(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.webFontTxtInst = {}; 
var loadedTypekitCount = 0;
var loadedGoogleCount = 0;
var gFontsUpdateCacheList = [];
var tFontsUpdateCacheList = [];
lib.ssMetadata = [
		{name:"final_banner_atlas_1", frames: [[722,0,440,440],[0,302,440,440],[0,0,720,300],[442,442,440,440],[0,744,440,440]]}
];



lib.updateListCache = function (cacheList) {		
	for(var i = 0; i < cacheList.length; i++) {		
		if(cacheList[i].cacheCanvas)		
			cacheList[i].updateCache();		
	}		
};		

lib.addElementsToCache = function (textInst, cacheList) {		
	var cur = textInst;		
	while(cur != null && cur != exportRoot) {		
		if(cacheList.indexOf(cur) != -1)		
			break;		
		cur = cur.parent;		
	}		
	if(cur != exportRoot) {		
		var cur2 = textInst;		
		var index = cacheList.indexOf(cur);		
		while(cur2 != null && cur2 != cur) {		
			cacheList.splice(index, 0, cur2);		
			cur2 = cur2.parent;		
			index++;		
		}		
	}		
	else {		
		cur = textInst;		
		while(cur != null && cur != exportRoot) {		
			cacheList.push(cur);		
			cur = cur.parent;		
		}		
	}		
};		

lib.gfontAvailable = function(family, totalGoogleCount) {		
	lib.properties.webfonts[family] = true;		
	var txtInst = lib.webFontTxtInst && lib.webFontTxtInst[family] || [];		
	for(var f = 0; f < txtInst.length; ++f)		
		lib.addElementsToCache(txtInst[f], gFontsUpdateCacheList);		

	loadedGoogleCount++;		
	if(loadedGoogleCount == totalGoogleCount) {		
		lib.updateListCache(gFontsUpdateCacheList);		
	}		
};		

lib.tfontAvailable = function(family, totalTypekitCount) {		
	lib.properties.webfonts[family] = true;		
	var txtInst = lib.webFontTxtInst && lib.webFontTxtInst[family] || [];		
	for(var f = 0; f < txtInst.length; ++f)		
		lib.addElementsToCache(txtInst[f], tFontsUpdateCacheList);		

	loadedTypekitCount++;		
	if(loadedTypekitCount == totalTypekitCount) {		
		lib.updateListCache(tFontsUpdateCacheList);		
	}		
};
(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.basket = function() {
	this.initialize(ss["final_banner_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ceramic = function() {
	this.initialize(ss["final_banner_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.counter_top = function() {
	this.initialize(ss["final_banner_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.dip_bowl = function() {
	this.initialize(ss["final_banner_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.wood_bowl = function() {
	this.initialize(ss["final_banner_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.text_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC6600").s().p("AwyQzMAAAghlMAhlAAAMAAAAhlg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-107.5,-107.5,215,215);


(lib.products = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_249 = function() {
		this.gotoAndPlay(9);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(249).call(this.frame_249).wait(1));

	// mask3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EgzyAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_159 = new cjs.Graphics().p("EgzyAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_160 = new cjs.Graphics().p("EgyoAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_161 = new cjs.Graphics().p("EgxfAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_162 = new cjs.Graphics().p("EgwVAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_163 = new cjs.Graphics().p("EgvMAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_164 = new cjs.Graphics().p("EguCAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_165 = new cjs.Graphics().p("Egs5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_166 = new cjs.Graphics().p("EgrvAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_167 = new cjs.Graphics().p("EgqmAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_168 = new cjs.Graphics().p("EgpcAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_169 = new cjs.Graphics().p("EgoTAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_170 = new cjs.Graphics().p("EgnJAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_171 = new cjs.Graphics().p("EgmAAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_172 = new cjs.Graphics().p("Egk2AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_173 = new cjs.Graphics().p("EgjtAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_174 = new cjs.Graphics().p("EgijAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_175 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_176 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_177 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_178 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_179 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_180 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_181 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_182 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_183 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_184 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_185 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_186 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_187 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_188 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_189 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_219 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_220 = new cjs.Graphics().p("Egh5AXgMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_221 = new cjs.Graphics().p("Egh5AXgMAAAgu/MBDzAAAMAAAAu/g");
	var mask_graphics_222 = new cjs.Graphics().p("Egh5AXgMAAAgu/MBDzAAAMAAAAu/g");
	var mask_graphics_223 = new cjs.Graphics().p("Egh5AXhMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_224 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_225 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_226 = new cjs.Graphics().p("Egh5AW/MAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_227 = new cjs.Graphics().p("Egh5AWNMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_228 = new cjs.Graphics().p("Egh5AVaMAAAgu/MBDzAAAMAAAAu/g");
	var mask_graphics_229 = new cjs.Graphics().p("Egh5AUoMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_230 = new cjs.Graphics().p("Egh5AT2MAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_231 = new cjs.Graphics().p("Egh5ATEMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_232 = new cjs.Graphics().p("Egh5ASSMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_233 = new cjs.Graphics().p("Egh5ARgMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_234 = new cjs.Graphics().p("Egh5AQtMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_235 = new cjs.Graphics().p("Egh5AP7MAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_236 = new cjs.Graphics().p("Egh5APJMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_237 = new cjs.Graphics().p("Egh5AOXMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_238 = new cjs.Graphics().p("Egh5ANlMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_239 = new cjs.Graphics().p("Egh5AMzMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_240 = new cjs.Graphics().p("Egh5AMAMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_241 = new cjs.Graphics().p("Egh5ALOMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_242 = new cjs.Graphics().p("Egh5AKcMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_243 = new cjs.Graphics().p("Egh5AJqMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_244 = new cjs.Graphics().p("Egh5AI4MAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_245 = new cjs.Graphics().p("Egh5AIGMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_246 = new cjs.Graphics().p("Egh5AHUMAAAgvBMBDzAAAMAAAAvBg");
	var mask_graphics_247 = new cjs.Graphics().p("Egh5AGhMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_248 = new cjs.Graphics().p("Egh5AFvMAAAgvAMBDzAAAMAAAAvAg");
	var mask_graphics_249 = new cjs.Graphics().p("Egh5AE9MAAAgvAMBDzAAAMAAAAvAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-331.475,y:-86.95}).wait(159).to({graphics:mask_graphics_159,x:-331.475,y:-86.95}).wait(1).to({graphics:mask_graphics_160,x:-324.1258,y:-86.95}).wait(1).to({graphics:mask_graphics_161,x:-316.7767,y:-86.95}).wait(1).to({graphics:mask_graphics_162,x:-309.4275,y:-86.95}).wait(1).to({graphics:mask_graphics_163,x:-302.0783,y:-86.95}).wait(1).to({graphics:mask_graphics_164,x:-294.7292,y:-86.95}).wait(1).to({graphics:mask_graphics_165,x:-287.38,y:-86.95}).wait(1).to({graphics:mask_graphics_166,x:-280.0308,y:-86.95}).wait(1).to({graphics:mask_graphics_167,x:-272.6817,y:-86.95}).wait(1).to({graphics:mask_graphics_168,x:-265.3325,y:-86.95}).wait(1).to({graphics:mask_graphics_169,x:-257.9833,y:-86.95}).wait(1).to({graphics:mask_graphics_170,x:-250.6342,y:-86.95}).wait(1).to({graphics:mask_graphics_171,x:-243.285,y:-86.95}).wait(1).to({graphics:mask_graphics_172,x:-235.9358,y:-86.95}).wait(1).to({graphics:mask_graphics_173,x:-228.5867,y:-86.95}).wait(1).to({graphics:mask_graphics_174,x:-221.2375,y:-86.95}).wait(1).to({graphics:mask_graphics_175,x:-210.7767,y:-86.95}).wait(1).to({graphics:mask_graphics_176,x:-196.0783,y:-86.95}).wait(1).to({graphics:mask_graphics_177,x:-181.38,y:-86.95}).wait(1).to({graphics:mask_graphics_178,x:-166.6817,y:-86.95}).wait(1).to({graphics:mask_graphics_179,x:-151.9833,y:-86.95}).wait(1).to({graphics:mask_graphics_180,x:-137.285,y:-86.95}).wait(1).to({graphics:mask_graphics_181,x:-122.5867,y:-86.95}).wait(1).to({graphics:mask_graphics_182,x:-107.8883,y:-86.95}).wait(1).to({graphics:mask_graphics_183,x:-93.19,y:-86.95}).wait(1).to({graphics:mask_graphics_184,x:-78.4917,y:-86.95}).wait(1).to({graphics:mask_graphics_185,x:-63.7933,y:-86.95}).wait(1).to({graphics:mask_graphics_186,x:-49.095,y:-86.95}).wait(1).to({graphics:mask_graphics_187,x:-34.3967,y:-86.95}).wait(1).to({graphics:mask_graphics_188,x:-19.6983,y:-86.95}).wait(1).to({graphics:mask_graphics_189,x:-5,y:-86.95}).wait(30).to({graphics:mask_graphics_219,x:-5,y:-86.95}).wait(1).to({graphics:mask_graphics_220,x:-5,y:-96.9833}).wait(1).to({graphics:mask_graphics_221,x:-5,y:-107.0167}).wait(1).to({graphics:mask_graphics_222,x:-5,y:-117.05}).wait(1).to({graphics:mask_graphics_223,x:-5,y:-127.0833}).wait(1).to({graphics:mask_graphics_224,x:-5,y:-137.1167}).wait(1).to({graphics:mask_graphics_225,x:-5,y:-147.15}).wait(1).to({graphics:mask_graphics_226,x:-5,y:-153.8167}).wait(1).to({graphics:mask_graphics_227,x:-5,y:-158.8333}).wait(1).to({graphics:mask_graphics_228,x:-5,y:-163.85}).wait(1).to({graphics:mask_graphics_229,x:-5,y:-168.8667}).wait(1).to({graphics:mask_graphics_230,x:-5,y:-173.8833}).wait(1).to({graphics:mask_graphics_231,x:-5,y:-178.9}).wait(1).to({graphics:mask_graphics_232,x:-5,y:-183.9167}).wait(1).to({graphics:mask_graphics_233,x:-5,y:-188.9333}).wait(1).to({graphics:mask_graphics_234,x:-5,y:-193.95}).wait(1).to({graphics:mask_graphics_235,x:-5,y:-198.9667}).wait(1).to({graphics:mask_graphics_236,x:-5,y:-203.9833}).wait(1).to({graphics:mask_graphics_237,x:-5,y:-209}).wait(1).to({graphics:mask_graphics_238,x:-5,y:-214.0167}).wait(1).to({graphics:mask_graphics_239,x:-5,y:-219.0333}).wait(1).to({graphics:mask_graphics_240,x:-5,y:-224.05}).wait(1).to({graphics:mask_graphics_241,x:-5,y:-229.0667}).wait(1).to({graphics:mask_graphics_242,x:-5,y:-234.0833}).wait(1).to({graphics:mask_graphics_243,x:-5,y:-239.1}).wait(1).to({graphics:mask_graphics_244,x:-5,y:-244.1167}).wait(1).to({graphics:mask_graphics_245,x:-5,y:-249.1333}).wait(1).to({graphics:mask_graphics_246,x:-5,y:-254.15}).wait(1).to({graphics:mask_graphics_247,x:-5,y:-259.1667}).wait(1).to({graphics:mask_graphics_248,x:-5,y:-264.1833}).wait(1).to({graphics:mask_graphics_249,x:-5,y:-269.2}).wait(1));

	// ceramic
	this.instance = new lib.ceramic();
	this.instance.setTransform(-225,-221);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(250));

	// mask2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Egh5AFCMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_99 = new cjs.Graphics().p("Egh5AFCMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_100 = new cjs.Graphics().p("Egh5AF0MAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_101 = new cjs.Graphics().p("Egh5AGlMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_102 = new cjs.Graphics().p("Egh5AHXMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_103 = new cjs.Graphics().p("Egh5AIJMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_104 = new cjs.Graphics().p("Egh5AI6MAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_105 = new cjs.Graphics().p("Egh5AJsMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_106 = new cjs.Graphics().p("Egh5AKeMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_107 = new cjs.Graphics().p("Egh5ALPMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_108 = new cjs.Graphics().p("Egh5AMBMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_109 = new cjs.Graphics().p("Egh5AMzMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_110 = new cjs.Graphics().p("Egh5ANkMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_111 = new cjs.Graphics().p("Egh5AOWMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_112 = new cjs.Graphics().p("Egh5APIMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_113 = new cjs.Graphics().p("Egh5AP5MAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_114 = new cjs.Graphics().p("Egh5AQrMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_115 = new cjs.Graphics().p("Egh5ARdMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_116 = new cjs.Graphics().p("Egh5ASOMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_117 = new cjs.Graphics().p("Egh5ATAMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_118 = new cjs.Graphics().p("Egh5ATyMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_119 = new cjs.Graphics().p("Egh5AUjMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_120 = new cjs.Graphics().p("Egh5AVVMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_121 = new cjs.Graphics().p("Egh5AWHMAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_122 = new cjs.Graphics().p("Egh5AW4MAAAgvAMBDzAAAMAAAAvAg");
	var mask_1_graphics_123 = new cjs.Graphics().p("Egh5AXgMAAAgu/MBDzAAAMAAAAu/g");
	var mask_1_graphics_124 = new cjs.Graphics().p("Egh5AXgMAAAgu/MBDzAAAMAAAAu/g");
	var mask_1_graphics_125 = new cjs.Graphics().p("Egh5AXgMAAAgu/MBDzAAAMAAAAu/g");
	var mask_1_graphics_126 = new cjs.Graphics().p("Egh5AXgMAAAgu/MBDzAAAMAAAAu/g");
	var mask_1_graphics_127 = new cjs.Graphics().p("Egh5AXgMAAAgu/MBDzAAAMAAAAu/g");
	var mask_1_graphics_128 = new cjs.Graphics().p("Egh5AXgMAAAgu/MBDzAAAMAAAAu/g");
	var mask_1_graphics_129 = new cjs.Graphics().p("Egh5AXgMAAAgvAMBDzAAAMAAAAvAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-6,y:-268.7}).wait(99).to({graphics:mask_1_graphics_99,x:-6,y:-268.7}).wait(1).to({graphics:mask_1_graphics_100,x:-6,y:-263.7333}).wait(1).to({graphics:mask_1_graphics_101,x:-6,y:-258.7667}).wait(1).to({graphics:mask_1_graphics_102,x:-6,y:-253.8}).wait(1).to({graphics:mask_1_graphics_103,x:-6,y:-248.8333}).wait(1).to({graphics:mask_1_graphics_104,x:-6,y:-243.8667}).wait(1).to({graphics:mask_1_graphics_105,x:-6,y:-238.9}).wait(1).to({graphics:mask_1_graphics_106,x:-6,y:-233.9333}).wait(1).to({graphics:mask_1_graphics_107,x:-6,y:-228.9667}).wait(1).to({graphics:mask_1_graphics_108,x:-6,y:-224}).wait(1).to({graphics:mask_1_graphics_109,x:-6,y:-219.0333}).wait(1).to({graphics:mask_1_graphics_110,x:-6,y:-214.0667}).wait(1).to({graphics:mask_1_graphics_111,x:-6,y:-209.1}).wait(1).to({graphics:mask_1_graphics_112,x:-6,y:-204.1333}).wait(1).to({graphics:mask_1_graphics_113,x:-6,y:-199.1667}).wait(1).to({graphics:mask_1_graphics_114,x:-6,y:-194.2}).wait(1).to({graphics:mask_1_graphics_115,x:-6,y:-189.2333}).wait(1).to({graphics:mask_1_graphics_116,x:-6,y:-184.2667}).wait(1).to({graphics:mask_1_graphics_117,x:-6,y:-179.3}).wait(1).to({graphics:mask_1_graphics_118,x:-6,y:-174.3333}).wait(1).to({graphics:mask_1_graphics_119,x:-6,y:-169.3667}).wait(1).to({graphics:mask_1_graphics_120,x:-6,y:-164.4}).wait(1).to({graphics:mask_1_graphics_121,x:-6,y:-159.4333}).wait(1).to({graphics:mask_1_graphics_122,x:-6,y:-154.4667}).wait(1).to({graphics:mask_1_graphics_123,x:-6,y:-148.55}).wait(1).to({graphics:mask_1_graphics_124,x:-6,y:-138.6167}).wait(1).to({graphics:mask_1_graphics_125,x:-6,y:-128.6833}).wait(1).to({graphics:mask_1_graphics_126,x:-6,y:-118.75}).wait(1).to({graphics:mask_1_graphics_127,x:-6,y:-108.8167}).wait(1).to({graphics:mask_1_graphics_128,x:-6,y:-98.8833}).wait(1).to({graphics:mask_1_graphics_129,x:-6,y:-88.95}).wait(121));

	// wood
	this.instance_1 = new lib.wood_bowl();
	this.instance_1.setTransform(-225,-219);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},190).wait(60));

	// mask1 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AxLXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_39 = new cjs.Graphics().p("AwyXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_40 = new cjs.Graphics().p("Ax9XhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_41 = new cjs.Graphics().p("AzHXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_42 = new cjs.Graphics().p("A0RXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_43 = new cjs.Graphics().p("A1cXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_44 = new cjs.Graphics().p("A2mXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_45 = new cjs.Graphics().p("A3wXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_46 = new cjs.Graphics().p("A47XhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_47 = new cjs.Graphics().p("A6FXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_48 = new cjs.Graphics().p("A7PXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_49 = new cjs.Graphics().p("A8aXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_50 = new cjs.Graphics().p("A9kXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_51 = new cjs.Graphics().p("A+uXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_52 = new cjs.Graphics().p("A/5XhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_53 = new cjs.Graphics().p("EghDAXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_54 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_55 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_56 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_57 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_58 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_59 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_60 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_61 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_62 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_63 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_64 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_65 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_66 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_67 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_68 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");
	var mask_2_graphics_69 = new cjs.Graphics().p("Egh5AXhMAAAgvBMBDzAAAMAAAAvBg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:323.975,y:-90.55}).wait(39).to({graphics:mask_2_graphics_39,x:326.475,y:-90.55}).wait(1).to({graphics:mask_2_graphics_40,x:319.0417,y:-90.55}).wait(1).to({graphics:mask_2_graphics_41,x:311.6083,y:-90.55}).wait(1).to({graphics:mask_2_graphics_42,x:304.175,y:-90.55}).wait(1).to({graphics:mask_2_graphics_43,x:296.7417,y:-90.55}).wait(1).to({graphics:mask_2_graphics_44,x:289.3083,y:-90.55}).wait(1).to({graphics:mask_2_graphics_45,x:281.875,y:-90.55}).wait(1).to({graphics:mask_2_graphics_46,x:274.4417,y:-90.55}).wait(1).to({graphics:mask_2_graphics_47,x:267.0083,y:-90.55}).wait(1).to({graphics:mask_2_graphics_48,x:259.575,y:-90.55}).wait(1).to({graphics:mask_2_graphics_49,x:252.1417,y:-90.55}).wait(1).to({graphics:mask_2_graphics_50,x:244.7083,y:-90.55}).wait(1).to({graphics:mask_2_graphics_51,x:237.275,y:-90.55}).wait(1).to({graphics:mask_2_graphics_52,x:229.8417,y:-90.55}).wait(1).to({graphics:mask_2_graphics_53,x:222.4083,y:-90.55}).wait(1).to({graphics:mask_2_graphics_54,x:212.95,y:-90.55}).wait(1).to({graphics:mask_2_graphics_55,x:198.0833,y:-90.55}).wait(1).to({graphics:mask_2_graphics_56,x:183.2167,y:-90.55}).wait(1).to({graphics:mask_2_graphics_57,x:168.35,y:-90.55}).wait(1).to({graphics:mask_2_graphics_58,x:153.4833,y:-90.55}).wait(1).to({graphics:mask_2_graphics_59,x:138.6167,y:-90.55}).wait(1).to({graphics:mask_2_graphics_60,x:123.75,y:-90.55}).wait(1).to({graphics:mask_2_graphics_61,x:108.8833,y:-90.55}).wait(1).to({graphics:mask_2_graphics_62,x:94.0167,y:-90.55}).wait(1).to({graphics:mask_2_graphics_63,x:79.15,y:-90.55}).wait(1).to({graphics:mask_2_graphics_64,x:64.2833,y:-90.55}).wait(1).to({graphics:mask_2_graphics_65,x:49.4167,y:-90.55}).wait(1).to({graphics:mask_2_graphics_66,x:34.55,y:-90.55}).wait(1).to({graphics:mask_2_graphics_67,x:19.6833,y:-90.55}).wait(1).to({graphics:mask_2_graphics_68,x:4.8167,y:-90.55}).wait(1).to({graphics:mask_2_graphics_69,x:-10.05,y:-90.55}).wait(181));

	// dip
	this.instance_2 = new lib.dip_bowl();
	this.instance_2.setTransform(-224,-220);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},190).wait(60));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-225,-221,441,284.5);


(lib.headline = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.text = new cjs.Text("ON \nSALE\nEVERY\nDAY", "normal 400 37px 'tk-anton'", "#FFFFFF");
	this.text.lineHeight = 45;
	this.text.lineWidth = 212;
	this.text.parent = this;
	this.text.setTransform(-106,-124.9);
	if(!lib.properties.webfonts['tk-anton']) {
		lib.webFontTxtInst['tk-anton'] = lib.webFontTxtInst['tk-anton'] || [];
		lib.webFontTxtInst['tk-anton'].push(this.text);
	}

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108,-126.9,216,253.8);


(lib.everydaythings_logosvg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// everydaythings_logo_svg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDABIAAgBQADAAAEABg");
	this.shape.setTransform(118.55,31.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhOCRIAAg6QAiAXAhAAQARAAAHgJQAJgJAAgQQAAgQgKgNQgJgNgWgQQgVgNgLgMQgLgNgGgQQgFgRAAgUQgBgrAWgWQAZgXAkAAQAMAAAYAGIAAADIAIAAQASAHAIAFIgVAvIgWgLQgJgEgPAAQgMAAgIAJQgJAIAAARQAAARAJALQANAOATAMQAcATAOAXQANAWAAAcQAAAtgXAWQgYAXgoAAQgkAAgigRg");
	this.shape_1.setTransform(113.8,47.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AA7CgIgShNIhQAAIgSBNIgzAAQgFAAgDgCIBNk9IBOAAIBOE/gAAeAcIgeiOQgBAMgGAdIgWBlIA7AAg");
	this.shape_2.setTransform(129.95,15.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AiUEUQgegqAAhOQAAhOAigpQAjgqA6AAIAQABIAIABIAAk6IBYAAQA3AAAeAqQAeAoADBLQAABNghArQgfAqg7AAIg/AAQAOAAASAMIgTAuQgegPgTAAQghAAgVAeQgSAegBAzQABA3AOAZQAOAdAbAAQAQAAARgDIAAhJIgsAAIAAg3IBiAAIAACmQgxASgoAAQg3AAgfgqgAAmg1IARAAQAgAAAOgZQAQgdAAgyQAAhpg6AAIgVAAg");
	this.shape_3.setTransform(100.75,31.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AA8E6IAAiEIhNAAIAACDIg3AAIAAk0IAhAAIhKk+IA6AAIAqC/QAIApADAfQACgVAIgxIApjBIA6AAIhJE/IgzAAIAAB5IBNAAIAAh5IA2AAIAAE0g");
	this.shape_4.setTransform(28.15,31.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdCgIAAh/IhJjAIA+AAIAoB9IAqh9IA9AAIhOC+IAACBg");
	this.shape_5.setTransform(147.225,16.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcCgIAAh/IhLjAIA+AAIApB9IAqh9IA9AAIhMC+IAACBg");
	this.shape_6.setTransform(86.5,16.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhtE5IAAkzIAXAAIAAk+IBKAAQAwgBAWAZQAYAaAAAuQAAA9gpAYIA9CJIAIAAIAAEyIhGAAIhgjbIgDAAQAGARAAAhIAACqgAA7DjIAAgCIAEAAQgGgVAAgfIAAinIgSAAIgyh4IgUAAIAAB4IgEAAgAgfiqIAQAAQAVAAAHgLQAKgMAAgWQAAgYgKgJQgIgJgVAAIgPAAg");
	this.shape_7.setTransform(68.05,31.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgPE6IAAk0Ig3AAIAAk/ICOAAIAAA4IhNAAIAABMIBNAAIAAAsIhNAAIAABZIBNAAIAAA2IghAAIAAE0g");
	this.shape_8.setTransform(47.9,31.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgWE6IAAkIIhBAAIAAgsIALAAIAAk/ICOAAIAAA4IhMAAIAABMIBMAAIAAAsIhMAAIAABZIBMAAIAAA2IAWAAIAAAsIg4AAIAAEIg");
	this.shape_9.setTransform(8.775,31.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,157.5,63.6);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiwFgIAAq/IABgBIFgFgIlgFhg");
	this.shape.setTransform(13.05,-21.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// text
	this.text = new cjs.Text("SHOP\nNOW", "normal 400 37px 'tk-anton'", "#FFFFFF");
	this.text.lineHeight = 45;
	this.text.lineWidth = 165;
	this.text.parent = this;
	this.text.setTransform(-82.5,-72.45);
	if(!lib.properties.webfonts['tk-anton']) {
		lib.webFontTxtInst['tk-anton'] = lib.webFontTxtInst['tk-anton'] || [];
		lib.webFontTxtInst['tk-anton'].push(this.text);
	}

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.5,-74.4,169.1,148.9);


(lib.button = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,51,51,0.498)").s().p("Eg4PAXcMAAAgu3MBwfAAAMAAAAu3g");
	this.shape.setTransform(0.025,0);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-359.9,-150,719.9,300.1);


(lib.basket_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.basket();
	this.instance.setTransform(-220,-220);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-220,-220,440,440);


// stage content:
(lib.finalbanner = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,209];
	// timeline functions:
	this.frame_0 = function() {
		this.btn_main_link.addEventListener("click", fl_ClickToGoToWebPage);
		
		function fl_ClickToGoToWebPage() {
			window.open("http://www.bagbywebsitesolutions.com", "_blank");
		}
	}
	this.frame_209 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(209).call(this.frame_209).wait(6));

	// button
	this.btn_main_link = new lib.button();
	this.btn_main_link.name = "btn_main_link";
	this.btn_main_link.setTransform(359.95,149.95);
	new cjs.ButtonHelper(this.btn_main_link, 0, 1, 2, false, new lib.button(), 3);

	this.timeline.addTween(cjs.Tween.get(this.btn_main_link).wait(215));

	// products
	this.instance = new lib.products();
	this.instance.setTransform(332,240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(215));

	// cta
	this.instance_1 = new lib.cta("synched",0);
	this.instance_1.setTransform(488.45,280.3);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(186).to({_off:false},0).to({x:645.45},19,cjs.Ease.get(1)).wait(10));

	// basket
	this.instance_2 = new lib.basket_1("synched",0);
	this.instance_2.setTransform(-236.75,252.4,1,1,-135,0,0,1.3,12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:-1.8,regY:12.6,scaleX:0.9999,rotation:0,x:324.1,y:254.2},39,cjs.Ease.get(1)).wait(176));

	// headline
	this.instance_3 = new lib.headline("synched",0);
	this.instance_3.setTransform(670,-60);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(96).to({startPosition:0},0).to({y:137.4},20,cjs.Ease.get(1)).wait(99));

	// text_box
	this.instance_4 = new lib.text_box("synched",0);
	this.instance_4.setTransform(832.4,107.5,0.7907,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(96).to({x:832.45},0).to({x:633.75,y:107.4},21,cjs.Ease.get(1)).wait(98));

	// logo_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EgtSALHIAW2CMAs3AAAIAAE8QkABfjQB/QjZCEjLC9QiQCHhkB2QiCCahHCQg");
	var mask_graphics_1 = new cjs.Graphics().p("Egq/ALHIAW2CMAs1AAAIAAE8Qj+BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_2 = new cjs.Graphics().p("EgoxALHIAW2CMAs2AAAIAAE8QkABfjPB/QjZCEjLC9QiQCHhjB2QiDCahHCQg");
	var mask_graphics_3 = new cjs.Graphics().p("EgmmALHIAW2CMAs2AAAIAAE8QkABfjPB/QjZCEjLC9QiQCHhjB2QiDCahHCQg");
	var mask_graphics_4 = new cjs.Graphics().p("EgkfALHIAW2CMAs2AAAIAAE8QkABfjQB/QjYCEjLC9QiQCHhjB2QiDCahHCQg");
	var mask_graphics_5 = new cjs.Graphics().p("EgibALHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjJC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_6 = new cjs.Graphics().p("EggcALHIAW2CMAs2AAAIAAE8QkABfjQB/QjZCEjKC9QiQCHhjB2QiDCahHCQg");
	var mask_graphics_7 = new cjs.Graphics().p("A+gLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiPCHhkB2QiDCahGCQg");
	var mask_graphics_8 = new cjs.Graphics().p("A8oLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhjB2QiDCahGCQg");
	var mask_graphics_9 = new cjs.Graphics().p("A60LHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiCCahGCQg");
	var mask_graphics_10 = new cjs.Graphics().p("A5ELHIAW2CMAs2AAAIAAE8QkABfjQB/QjZCEjLC9QiQCHhjB2QiDCahGCQg");
	var mask_graphics_11 = new cjs.Graphics().p("A3XLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_12 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_13 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_14 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_15 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_16 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_17 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_18 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_19 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_20 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_21 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_22 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_23 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_24 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_25 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_26 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_27 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_28 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_29 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_30 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_31 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_32 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_33 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_34 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_35 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_36 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_37 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_38 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");
	var mask_graphics_39 = new cjs.Graphics().p("A2lLHIAW2CMAs1AAAIAAE8Qj/BfjQB/QjaCEjKC9QiQCHhkB2QiDCahGCQg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-289.9,y:71.05}).wait(1).to({graphics:mask_graphics_1,x:-275.2454,y:71.05}).wait(1).to({graphics:mask_graphics_2,x:-260.9715,y:71.05}).wait(1).to({graphics:mask_graphics_3,x:-247.0783,y:71.05}).wait(1).to({graphics:mask_graphics_4,x:-233.5656,y:71.05}).wait(1).to({graphics:mask_graphics_5,x:-220.4336,y:71.05}).wait(1).to({graphics:mask_graphics_6,x:-207.6822,y:71.05}).wait(1).to({graphics:mask_graphics_7,x:-195.3115,y:71.05}).wait(1).to({graphics:mask_graphics_8,x:-183.3214,y:71.05}).wait(1).to({graphics:mask_graphics_9,x:-171.712,y:71.05}).wait(1).to({graphics:mask_graphics_10,x:-160.4832,y:71.05}).wait(1).to({graphics:mask_graphics_11,x:-149.635,y:71.05}).wait(1).to({graphics:mask_graphics_12,x:-133.7099,y:71.05}).wait(1).to({graphics:mask_graphics_13,x:-113.5361,y:71.05}).wait(1).to({graphics:mask_graphics_14,x:-94.1236,y:71.05}).wait(1).to({graphics:mask_graphics_15,x:-75.4723,y:71.05}).wait(1).to({graphics:mask_graphics_16,x:-57.5824,y:71.05}).wait(1).to({graphics:mask_graphics_17,x:-40.4537,y:71.05}).wait(1).to({graphics:mask_graphics_18,x:-24.0862,y:71.05}).wait(1).to({graphics:mask_graphics_19,x:-8.4801,y:71.05}).wait(1).to({graphics:mask_graphics_20,x:6.3648,y:71.05}).wait(1).to({graphics:mask_graphics_21,x:20.4484,y:71.05}).wait(1).to({graphics:mask_graphics_22,x:33.7707,y:71.05}).wait(1).to({graphics:mask_graphics_23,x:46.3317,y:71.05}).wait(1).to({graphics:mask_graphics_24,x:58.1315,y:71.05}).wait(1).to({graphics:mask_graphics_25,x:69.17,y:71.05}).wait(1).to({graphics:mask_graphics_26,x:79.4472,y:71.05}).wait(1).to({graphics:mask_graphics_27,x:88.9632,y:71.05}).wait(1).to({graphics:mask_graphics_28,x:97.7178,y:71.05}).wait(1).to({graphics:mask_graphics_29,x:105.7112,y:71.05}).wait(1).to({graphics:mask_graphics_30,x:112.9433,y:71.05}).wait(1).to({graphics:mask_graphics_31,x:119.4142,y:71.05}).wait(1).to({graphics:mask_graphics_32,x:125.1238,y:71.05}).wait(1).to({graphics:mask_graphics_33,x:130.072,y:71.05}).wait(1).to({graphics:mask_graphics_34,x:134.2591,y:71.05}).wait(1).to({graphics:mask_graphics_35,x:137.6848,y:71.05}).wait(1).to({graphics:mask_graphics_36,x:140.3493,y:71.05}).wait(1).to({graphics:mask_graphics_37,x:142.2524,y:71.05}).wait(1).to({graphics:mask_graphics_38,x:143.3944,y:71.05}).wait(1).to({graphics:mask_graphics_39,x:143.775,y:71.05}).wait(176));

	// logo
	this.instance_5 = new lib.everydaythings_logosvg("synched",0);
	this.instance_5.setTransform(104.8,67.8,1,1,0,0,0,78.8,31.8);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(215));

	// counter_top
	this.instance_6 = new lib.counter_top();

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(215));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-195.9,-147.4,1175.9,720.6999999999999);
// library properties:
lib.properties = {
	id: '11566901DCF3CE4A9F938592A0B7F1B7',
	width: 720,
	height: 300,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	webfonts: {},
	manifest: [
		{src:"images/final_banner_atlas_1.png?1603324152295", id:"final_banner_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['11566901DCF3CE4A9F938592A0B7F1B7'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;