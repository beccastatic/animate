(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"personal7_atlas_1", frames: [[0,502,696,77],[698,502,302,63],[0,674,274,63],[741,645,278,63],[0,581,850,31],[0,614,795,29],[0,645,739,27],[276,710,683,25],[276,737,627,23],[0,762,571,21],[0,785,515,20],[276,674,460,17],[573,762,404,16],[276,693,348,14],[0,807,295,12],[752,445,243,10],[752,457,192,10],[752,469,141,10],[895,469,89,10],[959,0,40,10],[752,305,100,68],[796,780,67,68],[940,567,79,68],[854,305,100,68],[942,375,80,68],[573,780,77,68],[854,375,86,68],[752,375,100,68],[852,567,86,68],[0,0,750,500],[752,0,205,303],[652,780,70,71],[724,780,70,71]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_110 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_113 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_112 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_111 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_109 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_108 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_107 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_106 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_105 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_104 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_103 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_102 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_101 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_100 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_99 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_98 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_97 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_96 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_95 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_94 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_93 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_92 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_91 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_90 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_89 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_88 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_87 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_86 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_85 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Background = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.buttoncolor = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.buttongray = function() {
	this.initialize(ss["personal7_atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.GotoWeb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D2D4D5").s().p("AgWE/IgIgBIgagDQhjgShHhHQhHhHgRhjIgCgNIgBgBIgBgNIAAg1IAAgEIABgNIABgCIABgMIABgBQAThpBPhKQBQhJBsgKIAOgBIAqABQBsAKBQBJQBPBKATBpIABABIABAMIABACIABANIAAAEIABAJIAAAmIgEAgIgBABQgGAlgPAjIg8g2IAAAAIgZgXQAVgFAMgEQAEgUAAgWQAAgWgEgTQg4gThHgIIACAjIgagXQgIgHgKgFIgBgDQgcgCgrAAQgsAAgcACQgCAeAAApQAAAqACAeQAmADAigBIAAAAIAAArIAAAAQgfAAglgCQAIBHATA4QAVADAUAAIAAAAIAABLgAhaDkQgOg1gHhAQhAgHg1gOQATAwAkAjQAkAkAvATIAAAAgAhyBEQgDgkAAggQAAgeADgmQhHAIg4ATQgEATAAAWQAAAXAEATQA1ARBKAJIAAAAgADkhZQgTgwgkgjQgkglgvgSQAOAzAHBCQBBAGA0APIAAAAgAitisQgkAjgTAwQA0gPBBgGQAHhBAOg0QgvASgkAlgABDhyQgIhKgSg1QgTgEgWABQgWgBgTAEQgTA4gIBHQAegCAmAAQAmAAAdACIAAAAg");
	this.shape.setTransform(0.075,-1.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D2D4D5").s().p("AgnBCIhXBXIAAlUID+DpIh3AAIA9B3IguAXg");
	this.shape_1.setTransform(18.2,15.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.GotoWeb, new cjs.Rectangle(-31.8,-33.8,63.8,67.69999999999999), null);


(lib.globe_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// globe_anim
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D2D4D5").s().p("ACFDJIhTBRIAAk8IDxDZIhwAAIA6BuIgsAWgAgUEXIgIAAIgYgEQhdgQhDhCQhDhCgQhcIgCgMIgBgBIgBgMIAAg2IABgLIABgCIACgMIAAAAQAShjBKhEQBLhEBlgJIAOgBIAoABQBmAJBKBEQBLBEARBjIABAAIACAMIAAACIACAYIgEBBIgBABQgFAigPAhIg3gyIAAgBIgYgVIAfgJQADgSAAgTQAAgWgDgSQg1gRhDgHIACAgIgYgWQgIgGgJgEIgBgDQgagDgpAAQgpAAgaADQgCAbAAAoQAAAmACAcQAjACAgAAIABAAIAAAnIgBAAQgdAAgjgCQAIBCARA0QAVAEASAAIABgBIAABGgAhVDDQgMgygHg7Qg8gGgygNQASArAhAiQAjAhArASIAAAAgAhrAuQgCgigBgcQABgdACgjQhDAHg1ARQgCASAAAWQAAATACATQAzAQBFAIIAAAAgADWhlQgRgrgigiQgighgsgSQANAwAGA9QA+AGAwANIAAAAgAijiyQgiAigRArQAxgNA9gGQAHg8AMgxQgrASgjAhgABAh7QgIhFgRgyQgSgDgVAAQgVAAgSADQgRA1gIBCQAdgCAjAAQAjAAAdACIAAAAg");
	this.shape.setTransform(0,-299.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D2D4D5").s().p("ACFDJIhTBRIAAk8IDxDZIhwAAIA6BuIgsAWgAgUEXIgIAAIgYgEQhdgQhDhCQhDhCgQhcIgCgMIgBgBIgBgMIAAg2IABgLIABgCIACgMIAAAAQAShjBKhEQBLhEBlgJIAOgBIAoABQBmAJBKBEQBLBEARBjIABAAIACAMIAAACIACAYIgEBBIgBABQgFAigPAhIg3gyIAAgBIgYgVIAfgJQADgSAAgTQAAgWgDgSQg1gRhDgHIACAgIgYgWQgIgGgJgEIgBgDQgagDgpAAQgpAAgaADQgCAbAAAoQAAAmACAcQAjACAgAAIABAAIAAAnIgBAAQgdAAgjgCQAIBCARA0QAVAEASAAIABgBIAABGgAijCQQAjAhArASQgMgygHg7Qg8gGgygNQASArAhAigAjjg4QgCASAAAWQAAATACATQAzAQBFAIQgCgigBgcQABgdACgjQhDAHg1ARgABoh4QA+AGAwANQgRgrgigiQgighgsgSQANAwAGA9gAijiyQgiAigRArQAxgNA9gGQAHg8AMgxQgrASgjAhgABAh7QgIhFgRgyQgSgDgVAAQgVAAgSADQgRA1gIBCQAdgCAjAAQAjAAAdACIAAAAg");
	this.shape_1.setTransform(0,-289.625);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).wait(1).to({y:-279.275},0).wait(1).to({y:-268.925},0).wait(1).to({y:-258.575},0).wait(1).to({y:-248.275},0).wait(1).to({y:-237.925},0).wait(1).to({y:-227.575},0).wait(1).to({y:-217.225},0).wait(1).to({y:-206.875},0).wait(1).to({y:-196.525},0).wait(1).to({y:-186.175},0).wait(1).to({y:-175.825},0).wait(1).to({y:-165.475},0).wait(1).to({y:-155.125},0).wait(1).to({y:-144.825},0).wait(1).to({y:-134.475},0).wait(1).to({y:-124.125},0).wait(1).to({y:-113.775},0).wait(1).to({y:-103.425},0).wait(1).to({y:-93.075},0).wait(1).to({y:-82.725},0).wait(1).to({y:-72.375},0).wait(1).to({y:-62.025},0).wait(1).to({y:-51.675},0).wait(1).to({y:-41.375},0).wait(1).to({y:-31.025},0).wait(1).to({y:-20.675},0).wait(1).to({y:-10.325},0).wait(1).to({y:0.025},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30,-331.5,60,363.1);


(lib.btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_1 = function() {
		playSound("click");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(3));

	// button
	this.instance = new lib.buttongray();
	this.instance.setTransform(-35,-36);

	this.instance_1 = new lib.buttoncolor();
	this.instance_1.setTransform(9.85,-49.35,1,1,55.9991);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CC33").s().p("AyVGaQhMAAAAhMIAAqbQAAhMBMAAMAkrAAAQBMAAAABMIAAKbQAABMhMAAg");
	this.shape.setTransform(83.0919,5.2,0.8828,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-49,-49.3,242.5,97.69999999999999);


(lib.Welcome = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.GotoWeb();
	this.instance.setTransform(-71.55,-26.6);

	this.instance_1 = new lib.CachedBmp_110();
	this.instance_1.setTransform(-174,22.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Welcome, new cjs.Rectangle(-174,-60.4,348,121.1), null);


(lib.navbar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_69 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(69).call(this.frame_69).wait(1));

	// labels
	this.instance = new lib.CachedBmp_113();
	this.instance.setTransform(202,3.9,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_112();
	this.instance_1.setTransform(-3,3.9,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_111();
	this.instance_2.setTransform(-246,3.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(70));

	// buttons
	this.btn3 = new lib.btn();
	this.btn3.name = "btn3";
	this.btn3.setTransform(173,2,0.8857,0.8857);
	new cjs.ButtonHelper(this.btn3, 0, 1, 2, false, new lib.btn(), 3);

	this.btn2 = new lib.btn();
	this.btn2.name = "btn2";
	this.btn2.setTransform(-35,2,0.8857,0.8857);
	new cjs.ButtonHelper(this.btn2, 0, 1, 2, false, new lib.btn(), 3);

	this.btn1 = new lib.btn();
	this.btn1.name = "btn1";
	this.btn1.setTransform(-281,2,0.8857,0.8857);
	new cjs.ButtonHelper(this.btn1, 0, 1, 2, false, new lib.btn(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn1},{t:this.btn2},{t:this.btn3}]}).wait(70));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.098)").s().p("Eg3nAGGQg8AAAAg7IAAqVQAAg7A8AAMBvPAAAQA8AAAAA7IAAKVQAAA7g8AAg");
	this.shape.setTransform(0.025,2.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.2)").s().p("Eg3nAGGQg8AAAAg7IAAqVQAAg7A8AAMBvPAAAQA8AAAAA7IAAKVQAAA7g8AAg");
	this.shape_1.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},20).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(48).to({_off:true},1).wait(21));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-362,-41.7,724.1,86.6);


// stage content:
(lib.personal7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,1,70];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.started = false;
		this.startanim.addEventListener("click", clickToStart.bind(this));
		
		function clickToStart()
		{
			if(!this.started){
				this.started =true;
				this.play();
			}
		}
		
	}
	this.frame_1 = function() {
		this.nav.btn1.addEventListener("click", btn1Clicked.bind(this));
		this.nav.btn2.addEventListener("click", btn2Clicked.bind(this));
		this.nav.btn3.addEventListener("click", btn3Clicked.bind(this));
		
		function btn1Clicked() {
			window.open("http://www.google.com", "_blank");
		}
		function btn2Clicked() {
			window.open("http://www.scf.edu", "_blank");
		}
		function btn3Clicked() {
			window.open("http://www.usf.edu", "_blank");
		}
	}
	this.frame_70 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(69).call(this.frame_70).wait(1));

	// start
	this.startanim = new lib.Welcome();
	this.startanim.name = "startanim";
	this.startanim.setTransform(436.5,212);

	this.timeline.addTween(cjs.Tween.get(this.startanim).to({_off:true},1).wait(70));

	// navbar
	this.nav = new lib.navbar();
	this.nav.name = "nav";
	this.nav.setTransform(1121.1,369.6);
	this.nav._off = true;

	this.timeline.addTween(cjs.Tween.get(this.nav).wait(1).to({_off:false},0).wait(1).to({regY:1.6,x:1084.45,y:371.2},0).wait(1).to({x:1049},0).wait(1).to({x:1014.85},0).wait(1).to({x:981.85},0).wait(1).to({x:950},0).wait(1).to({x:919.3},0).wait(1).to({x:889.65},0).wait(1).to({x:861.05},0).wait(1).to({x:833.45},0).wait(1).to({x:806.85},0).wait(1).to({x:781.25},0).wait(1).to({x:756.5},0).wait(1).to({x:732.65},0).wait(1).to({x:709.65},0).wait(1).to({x:687.45},0).wait(1).to({x:666.1},0).wait(1).to({x:645.5},0).wait(1).to({x:625.6},0).wait(1).to({x:606.45},0).wait(1).to({x:588},0).wait(1).to({x:570.15},0).wait(1).to({x:552.95},0).wait(1).to({x:536.35},0).wait(1).to({x:520.35},0).wait(1).to({x:504.85},0).wait(1).to({x:489.95},0).wait(1).to({x:475.5},0).wait(1).to({x:461.55},0).wait(1).to({x:448.05},0).wait(1).to({x:435},0).wait(1).to({x:422.35},0).wait(1).to({x:410.1},0).wait(1).to({x:398.2},0).wait(1).to({x:386.65},0).wait(1).to({x:375.5},0).wait(1).to({x:375},0).wait(34));

	// subtitle
	this.instance = new lib.CachedBmp_93();
	this.instance.setTransform(611.8,145.75,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_92();
	this.instance_1.setTransform(582.35,145.75,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_91();
	this.instance_2.setTransform(547,145.75,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_90();
	this.instance_3.setTransform(501.45,145.75,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_89();
	this.instance_4.setTransform(465.55,145.75,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_88();
	this.instance_5.setTransform(431.1,145.75,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_87();
	this.instance_6.setTransform(392.15,145.75,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_86();
	this.instance_7.setTransform(346.6,145.75,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_85();
	this.instance_8.setTransform(308,145.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},1).wait(70));

	// title
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AMWhbIg5B3IBxAAgAGxBXIAbAOQgOAagRAPQgRAQgVAIQgVAJgbAAQg8AAgigoQgignAAgxQAAgvAdgjQAkguA9AAQA+AAAmAvQAaAhABAyIjcAAQABAqAaAbQAaAcAnAAQATAAARgHQASgGAMgLQANgLAOgYgAgyhLIAhAAIBSCxIBRixIAhAAIhvDzIgGAAgAWDgwIgUAUQgZgYgYAAQgQAAgKAKQgLAKAAAOQAAAMAJAJQAJALAcAPQAjASAOARQALARAAAWQAAAegUAVQgVAVggAAQgWAAgSgKQgUgJgMgQIATgXQAYAcAbAAQATAAAOgMQANgNAAgQQAAgNgJgLQgJgKgegQQgigRgLgRQgNgQAAgVQAAgcAUgSQATgSAdAAQAiAAAhAhgASIimIAfAAIAABbIAyAAIAAAbIgyAAIAADYIgfAAIAAjYIgrAAIAAgbIArAAgAPWhLIAhAAIAAAkQAOgWAQgKQAQgKARAAQANAAAPAIIgQAaQgKgEgHAAQgQAAgOANQgPANgIAaQgFAVAABAIAABSIghAAgAwPhLIAhAAIAAAkQAOgWAQgKQAQgKASAAQANAAAOAIIgQAaQgKgEgHAAQgPAAgPANQgPANgHAaQgGAVAABAIAABSIghAAgAqqBXIAbAOQgNAagSAPQgRAQgVAIQgVAJgbAAQg8AAgigoQgignAAgxQAAgvAcgjQAlguA9AAQA+AAAmAvQAaAhABAyIjcAAQAAAqAbAbQAaAcAnAAQASAAASgHQARgGANgLQAMgLAPgYgAw/hkIgbAUQgVgcgegOQgegPglAAQgoAAghATQgiATgSAgQgTAgAAAnQAAA8AqApQApAoA/AAQBGAAAug2IAbAUQgZAfglARQglASguAAQhXAAgyg6QgpgxAAhFQAAhHAzgyQAygxBNAAQAuAAAlASQAlASAZAhgAhsiwQALAAAHAIQAIAIAAAKQAAALgIAHQgHAIgLAAQgKAAgIgIQgIgHAAgLQAAgKAIgIQAIgIAKAAgAh7hLIAfAAIAADzIgfAAgAj3imIAfAAIAABbIAyAAIAAAbIgyAAIAADYIgfAAIAAjYIgrAAIAAgbIArAAgAlZhLIAADzIggAAIAAgqQgTAYgYAMQgZANgdAAQg1AAgkgmQglgmAAg2QAAgzAlgmQAlglA1AAQAeAAAYAMQAYANASAaIAAgtg");
	this.shape.setTransform(478.65,116.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.996)").s().p("A1YB3QgqgxAAhFQAAhHAzgyQAygxBNAAQAuAAAlASQAmASAYAhIgbAUQgVgcgfgOQgdgPglAAQgnAAgiATQghATgTAgQgTAgAAAnQAAA8AqApQApAoA/AAQBGAAAug2IAbAUQgaAfgkARQglASguAAQhXAAgxg6gAURClQgTgJgNgQIAUgXQAYAcAbAAQATAAAOgMQANgNAAgQQAAgNgJgLQgJgKgegQQgigRgLgRQgMgQAAgVQgBgcAUgSQASgSAdAAQAjAAAiAhIgVAUQgZgYgYAAQgPAAgLAKQgMAKABAOQgBAMAKAJQAIALAdAPQAkASAMARQANARAAAWQAAAegWAVQgUAVghAAQgVAAgTgKgAD5CHQgignAAgxQAAgvAdgjQAkguA9AAQA+AAAmAvQAaAhABAyIjdAAQABAqAaAbQAbAcAnAAQASAAASgHQASgGAMgLQAMgLAPgYIAbAOQgOAagRAPQgRAQgVAIQgWAJgaAAQg9AAghgogAEXgcQgTARgJAgIC2AAQgGgYgMgPQgMgPgVgJQgTgJgWAAQgkAAgaAXgAozCJQglgmAAg2QAAgzAlgmQAlglA0AAQAeAAAZAMQAYANATAaIAAgtIAeAAIAADzIgeAAIAAgqQgUAYgYAMQgaANgcAAQg1AAgkgmgAoHgmQgXANgNAXQgNAWAAAbQAAAZANAYQANAXAXAOQAWANAZAAQAaAAAYgNQAWgNANgXQAMgWAAgcQAAgqgcgcQgbgcgpAAQgaAAgWANgAtiCHQgignAAgxQAAgvAdgjQAkguA9AAQA+AAAmAvQAaAhABAyIjdAAQABAqAaAbQAbAcAnAAQASAAASgHQASgGAMgLQAMgLAPgYIAbAOQgOAagRAPQgRAQgVAIQgWAJgaAAQg9AAghgogAtEgcQgTARgJAgIC2AAQgGgYgMgPQgMgPgVgJQgTgJgWAAQgkAAgaAXgASICoIAAjYIgrAAIAAgbIArAAIAAhbIAfAAIAABbIAzAAIAAAbIgzAAIAADYgAPWCoIAAjzIAhAAIAAAkQAOgWAQgKQAQgKARAAQANAAAPAIIgQAaQgLgEgHAAQgPAAgOANQgQANgHAaQgGAVABBAIAABSgAOQCoIg0hsIiOAAIgzBsIglAAICblJIAJAAICaFJgALdAcIBxAAIg4h3gAA+CoIhwjzIAiAAIBRCxIBQixIAiAAIhwDzgAh8CoIAAjzIAgAAIAADzgAj4CoIAAjYIgrAAIAAgbIArAAIAAhbIAgAAIAABbIAyAAIAAAbIgyAAIAADYgAwPCoIAAjzIAhAAIAAAkQAOgWAQgKQAQgKARAAQANAAAPAIIgQAaQgKgEgHAAQgPAAgPANQgPANgHAaQgGAVAABAIAABSgAh+iEQgIgHAAgLQAAgKAIgIQAHgIALAAQALAAAHAIQAIAIAAAKQAAALgIAHQgHAIgLAAQgLAAgHgIg");
	this.shape_1.setTransform(478.65,116.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},1).wait(70));

	// divider
	this.instance_9 = new lib.CachedBmp_94();
	this.instance_9.setTransform(473.9,231.3,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_95();
	this.instance_10.setTransform(460.9,229.4,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_96();
	this.instance_11.setTransform(447.85,227.4,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_97();
	this.instance_12.setTransform(434.85,225.35,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_98();
	this.instance_13.setTransform(421.85,223.25,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_99();
	this.instance_14.setTransform(408.8,220.25,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_100();
	this.instance_15.setTransform(395.8,217.25,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_101();
	this.instance_16.setTransform(382.8,214.25,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_102();
	this.instance_17.setTransform(369.75,211.2,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_103();
	this.instance_18.setTransform(356.75,207.75,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_104();
	this.instance_19.setTransform(343.75,205.15,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_105();
	this.instance_20.setTransform(330.7,202.1,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_106();
	this.instance_21.setTransform(317.7,199.1,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_107();
	this.instance_22.setTransform(304.7,196.1,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_108();
	this.instance_23.setTransform(291.65,193.05,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_109();
	this.instance_24.setTransform(278.65,189.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_9}]},10).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).wait(46));

	// web
	this.instance_25 = new lib.globe_anim("synched",0,false);
	this.instance_25.setTransform(479.6,262.25);
	this.instance_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(20).to({_off:false},0).wait(50).to({startPosition:29},0).wait(1));

	// person_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("AgEZCMAAAgyDIAJAAMAAAAyDg");
	var mask_graphics_2 = new cjs.Graphics().p("AhMZCMAAAgyDICZAAMAAAAyDg");
	var mask_graphics_3 = new cjs.Graphics().p("AiVZCMAAAgyCIErAAMAAAAyCg");
	var mask_graphics_4 = new cjs.Graphics().p("AjeZBMAAAgyBIG9AAMAAAAyBg");
	var mask_graphics_5 = new cjs.Graphics().p("AknZBMAAAgyBIJPAAMAAAAyBg");
	var mask_graphics_6 = new cjs.Graphics().p("AlvZAMAAAgx/ILfAAMAAAAx/g");
	var mask_graphics_7 = new cjs.Graphics().p("Am3ZAMAAAgx/INwAAMAAAAx/g");
	var mask_graphics_8 = new cjs.Graphics().p("AoAZAMAAAgx/IQBAAMAAAAx/g");
	var mask_graphics_9 = new cjs.Graphics().p("ApJZAMAAAgx/ISTAAMAAAAx/g");
	var mask_graphics_10 = new cjs.Graphics().p("AqSY/MAAAgx9IUlAAMAAAAx9g");
	var mask_graphics_11 = new cjs.Graphics().p("AraY/MAAAgx9IW1AAMAAAAx9g");
	var mask_graphics_12 = new cjs.Graphics().p("AsjY+MAAAgx7IZHAAMAAAAx7g");
	var mask_graphics_13 = new cjs.Graphics().p("AtrY+MAAAgx7IbYAAMAAAAx7g");
	var mask_graphics_14 = new cjs.Graphics().p("Au0Y+MAAAgx6IdpAAMAAAAx6g");
	var mask_graphics_15 = new cjs.Graphics().p("Av9Y9MAAAgx5If6AAMAAAAx5g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:13.5,y:185.275}).wait(1).to({graphics:mask_graphics_2,x:21.05,y:184.6}).wait(1).to({graphics:mask_graphics_3,x:28.6,y:183.9}).wait(1).to({graphics:mask_graphics_4,x:36.15,y:183.225}).wait(1).to({graphics:mask_graphics_5,x:43.7,y:182.575}).wait(1).to({graphics:mask_graphics_6,x:51.25,y:181.9}).wait(1).to({graphics:mask_graphics_7,x:58.8,y:181.2}).wait(1).to({graphics:mask_graphics_8,x:66.375,y:180.525}).wait(1).to({graphics:mask_graphics_9,x:73.9,y:179.85}).wait(1).to({graphics:mask_graphics_10,x:81.45,y:179.15}).wait(1).to({graphics:mask_graphics_11,x:89,y:178.475}).wait(1).to({graphics:mask_graphics_12,x:96.55,y:177.825}).wait(1).to({graphics:mask_graphics_13,x:104.1,y:177.15}).wait(1).to({graphics:mask_graphics_14,x:111.65,y:176.45}).wait(1).to({graphics:mask_graphics_15,x:119.2,y:175.775}).wait(36).to({graphics:null,x:0,y:0}).wait(20));

	// Person
	this.instance_26 = new lib.Bitmap2();
	this.instance_26.setTransform(9,23);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(1,1,1,0.196)").s().p("AgYgEIAnAAIAKAAQAAAEgBAAQgYAFgYAAIAAgJg");
	this.shape_2.setTransform(145.5,326.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(5,5,5,0.224)").s().p("AB9AFIkDAAIAAgJIAeAAIAKAAIDlAAIAAAJIgKAAg");
	this.shape_3.setTransform(114.5,326.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(0,0,0,0.663)").s().p("AgKAFIAAAAIAAgJIAKAAIAJAAQAAAEACAEIAAABg");
	this.shape_4.setTransform(98.125,22.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(6,6,6,0.592)").s().p("AghARQAugNAjACIAKABQAGgpA3AeQAEACAFAAIAAAJIgKAAIgKAAIAAAKIgKgBQgWgCgIgQIAAATIAAAAgAh/ARQAmgVARAVg");
	this.shape_5.setTransform(86.2125,21.3121);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(44,44,44,0.659)").s().p("AgOgMQAagHADARIAAAJQgFAAgDACQgHAGgGAAQgLAAADgbg");
	this.shape_6.setTransform(119.4542,21.3429);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(57,57,57,0.773)").s().p("AgBAAIAAAAIADAAg");
	this.shape_7.setTransform(113.2,23.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(20,20,20,0.733)").s().p("AgdAPQAGgIADgLIABgKIAKAAIAJAAQgFApAbgUQADgCAFAAIAAAKIAAAAg");
	this.shape_8.setTransform(118.0125,21.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(38,38,38,0.667)").s().p("AgKAPIgEAAQAAgFACgBQAOgHgQgQIATAAIAKAAIgBAKQgCALgHAIg");
	this.shape_9.setTransform(114.5,21.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(30,30,30,0.741)").s().p("AgJAAIAAAAIAJAAIAKAAIAAAAg");
	this.shape_10.setTransform(112,23.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(4,4,4,0.816)").s().p("AArAKQAJAAAHgEQACgBAAgFIAIAKgAgFAKIgBgBQgCgEAAgFIAAgJQAXASAUABgAhEAKIAAAAIAAgTQAIAQAWACIAKABIABAAg");
	this.shape_11.setTransform(99.9,22.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(6,6,6,0.624)").s().p("AAJAWQgTgCgYgTIAAgJQAggRAIAFQAEACAFAAQgHAaAbgCIAAAFQAAAFgCABQgHAEgJABIgEAAIgEAAg");
	this.shape_12.setTransform(102.5,20.8677);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(5,5,5,0.576)").s().p("AgTgCIAAgKIAdAAIAKAAIgBAKQgDAPgJAAQgJAAgRgPg");
	this.shape_13.setTransform(107,19.2875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(0,0,0,0.294)").s().p("AihYjIEHAAQhKAIhBAAQhCAAg6gIgAkj2yQBRg4BngiQBMAAAzgYQACgBAAgFIEEAAIAKAAIAAAKIAAAFQguADgYAWIAAgFQhAAhgugcQAAAFgCABQgeARgwgDIAAAFQgkACgNAXIgKAAIgoAAQAAAFgBAAQgnAMgjANg");
	this.shape_14.setTransform(74.7625,168.9182);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(20,20,20,0.306)").s().p("AgdAAIAAgKIAxAAIAKAAIgBAKQgCAKgPAAQgNAAgcgKg");
	this.shape_15.setTransform(107,12.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(76,76,76,0.729)").s().p("AgBAFQgHgFgOgEIAUAAIAJAAQAJAEAHAFg");
	this.shape_16.setTransform(136.275,22.525);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(47,47,47,0.675)").s().p("AgTAPIAAAAIAAgTQAKgFAKgEQAEgBAFAAQAFAFADAGQACADAAAFIgKAAIgTAAQANAFAHAFg");
	this.shape_17.setTransform(135,21.525);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(11,11,11,0.773)").s().p("AgnAGIADgDQADgDAAgEIAKAAQAaALAGgIQACgDAFAAQAVgFADAPg");
	this.shape_18.setTransform(128.4375,22.461);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(40,40,40,0.702)").s().p("AgTAKIAAAAIAAgKQAFgEAGgDQAEgCAEAAQAFAFAGADQAEABAFAAQAAAFgDACIgDADg");
	this.shape_19.setTransform(123,22.025);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(18,18,18,0.592)").s().p("AB9AlQgDgPgVAFIgBgFQgagDgNgMQgFAAgFABQgKAEgKAFQgFAAgEACQgGADgFAFIgBgKQgCgRgaAHIgKAAIgKAAIgKAAIgUAAQAQARgOAHQgCABAAAFIgKAAIgKAAIAAAAIgqAAIgIgKIAAgFQgbABAHgZIAKAAQAhAeAGgeIABgKQAUgqA8AgIAEgIQABgCAFAAQApAHAmALQAFACAFAAQAXgwBAAzQADACAAAFIAAAJQgFAAgFABQgKAEgKAFIAAAUIAAAAg");
	this.shape_20.setTransform(119.936,19.3331);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(69,69,69,0.655)").s().p("AAFAKQgFAAgDgCQgGgDgFgFQAKgEAJgDQAFgCAFAAIAAAJIAAAKIgKAAg");
	this.shape_21.setTransform(124.5,21);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(37,37,37,0.663)").s().p("AgTAHIAAgJIAAgKQANAMAaACIAAAFQgFAAgCACQgCAEgHAAQgIAAgPgGg");
	this.shape_22.setTransform(128,21.3349);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(17,17,17,0.494)").s().p("AAFALIgTAAIAAgKIAAgJQAagHADAQIAAAKIgKAAg");
	this.shape_23.setTransform(155.5,20.8979);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(8,8,8,0.62)").s().p("AhdAUQgHgGgJgEQAAgFgCgEQgDgFgFgFIAAgKQBYAUBRgBIAEAIQABACAFAAIAUAAIAKAAQAFAAAFACIAUAIg");
	this.shape_24.setTransform(147.975,21.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(2,2,2,0.431)").s().p("ADUYsQgxgDhbADIAAgKICWAAIAAAKIgKAAgAjPYrQgXgGgcgDIA9AAIAAAKIgKgBgAGH2zIgUgIQgEgCgFAAIgBgKQgCgRgbAHIAAAKIAAAKQgFAAgBgCIgEgIQhSABhYgVQAAgFgDgCQhAgzgXAwQgFAAgFgCQgmgKgpgIQgFAAgBACIgEAIQg8gggUAqIgKAAIgeAAIAAAKIgKAAQgFAAgEgCQgJgGggASIAAAKQgFAAgEgCQg3gegGAqIgKAAQgjgDgvANIgnAAQgSgWglAWIiCAAQAkgNAmgMQACAAAAgFIAoAAIAKAAQAMgWAlgDIABgFQAwADAegRQACgBAAgFQAtAdBBgiIAAAFQAXgWAugDIABgFQA3AWAEgWIABgKIHBAAIAKAAQBbAdBGAwQAEADAFAAQAMgQAQAcQACADAAAFQAbgHAHAPQABACAFAAIAMAKg");
	this.shape_25.setTransform(120.8375,169);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(3,3,3,0.2)").s().p("ABvA8IgMgKQgFAAgBgCQgHgPgbAHQAAgFgCgEQgQgbgMAQQgFAAgDgDQhGgvhbgdIAoAAIAKAAQANARAlgGIAKgBQBhArBKBCg");
	this.shape_26.setTransform(170.1,17.025);

	var maskedShapeInstanceList = [this.instance_26,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.instance_26}]},1).wait(70));

	// Gradient
	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(0,0,0,0.996)","rgba(0,0,0,0)"],[0,1],-481.2,537.8,-115.8,742.6).s().p("Eg6hAj4MAAAhHvMB1DAAAMAAABHvg");
	this.shape_27.setTransform(359.475,227.8174,1,1.0218);
	this.shape_27._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_27).wait(1).to({_off:false},0).wait(70));

	// Texture
	this.instance_27 = new lib.Background();
	this.instance_27.setTransform(-10,-2,1.0261,0.9216);

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(71));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(361.4,140.8,1121.8000000000002,321.59999999999997);
// library properties:
lib.properties = {
	id: 'DC172E9C241972478ABB52736814AD00',
	width: 753,
	height: 420,
	fps: 30,
	color: "#E2C59F",
	opacity: 1.00,
	manifest: [
		{src:"images/personal7_atlas_1.png", id:"personal7_atlas_1"},
		{src:"sounds/click.mp3", id:"click"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['DC172E9C241972478ABB52736814AD00'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;